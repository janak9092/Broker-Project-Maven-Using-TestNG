package Browser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Browser {

    static {
        WebDriverManager.chromedriver().setup(); // Automatically handles versioning
    }

    public static WebDriver createDriver() {
        ChromeOptions options = new ChromeOptions();
        
        // Optional: run headless (no GUI)
        // options.addArguments("--headless=new"); // Uncomment if needed
        
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-popup-blocking");

        WebDriver driver = new ChromeDriver(options);
        return driver;
    }
}
