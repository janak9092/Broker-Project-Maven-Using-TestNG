package Main;

import Browser.Browser;
import Project.Followup;
import Project.Inquiry;
import Project.Task;
import Project.Import;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.*;

import java.time.Duration;

public class Main {

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    @BeforeClass
    public void setUp() {
        driver = Browser.createDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        js = (JavascriptExecutor) driver;
        driver.manage().window().maximize();
    }

    @Test(priority = 1)
    public void login() {
        try {
            driver.get("https://auth-staging.nineformula.com");
            
            WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//input[@type='email' or contains(@placeholder,'Email')]")));
            emailInput.sendKeys("Kevin@gmail.com");

            WebElement continueBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(text(),'Continue')]")));
            js.executeScript("arguments[0].click();", continueBtn);

            wait.until(ExpectedConditions.urlContains("/login/password"));

            WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//input[@type='password']")));
            passwordInput.sendKeys("Kevin@123");

            WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(text(),'Log in')]")));
            js.executeScript("arguments[0].click();", loginBtn);

            wait.until(ExpectedConditions.urlContains("/products"));
            click(By.xpath("//span[text()='BROKER']"));

            wait.until(ExpectedConditions.urlContains("/organizations"));
            click(By.xpath("//span[text()='HL Group']"));

            wait.until(ExpectedConditions.urlContains("/dashboard"));
        } catch (Exception e) {
            System.err.println("❌ Login/navigation failed: " + e.getMessage());
        }
    }

    @Test(priority = 2 )
    public void runInquiry() {
        Inquiry inquiry = new Inquiry(driver);
        inquiry.setupPage();
        for (int i = 1; i <= 10; i++) {
        	
        	 System.out.println("🔄 Adding #" + (i));
            inquiry.testAddInquiry();}
        inquiry.afterClass();
    }

    @Test(priority = 3 )
    public void runTask() {
        Task task = new Task(driver);
        task.openTaskPage();
        for (int i = 1; i <= 10; i++) {
        	 System.out.println("🔄 Adding #" + (i));
        task.testTask();}
        task.finish();
    }

    @Test(priority = 4 )
    public void runFollowUp() {
        Followup followup = new Followup(driver);
        followup.openFollowUpPage();
        for (int i = 1; i <= 10; i++) {
        System.out.println("🔄 Adding #" + (i));
        followup.testFollowUp();}
        followup.finish();
    }

    @Test(priority = 5,  enabled = false)  // Use enabled = false instead of @Ignore
    public void runImport() {
        Import imp = new Import(driver);
        imp.testImport();
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    private void click(By xpath) {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(xpath));
        js.executeScript("arguments[0].scrollIntoView(true); arguments[0].click();", element);
    }
}
