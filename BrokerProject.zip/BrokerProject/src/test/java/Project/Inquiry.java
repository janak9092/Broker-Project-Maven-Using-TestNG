package Project;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.Random;

public class Inquiry {

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;

    public Inquiry(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        this.js = (JavascriptExecutor) driver;
    }
    @BeforeClass
    public void setupPage() {
        try {
            wait.until(ExpectedConditions.urlContains("/dashboard"));
            Thread.sleep(1000); // Optional, you can replace with a more stable wait

            WebElement inquiriesMenu = driver.findElement(By.xpath(
                "//a[contains(@href,'inquiries.index') and contains(@class,'menu-item')]"
            ));
            js.executeScript("arguments[0].click();", inquiriesMenu);
            Thread.sleep(2000);
        } catch (Exception e) {
            System.err.println("❌ Setup navigation failed: " + e.getMessage());
        }
    }
    @Test
    public void testAddInquiry() {
        try {
                // ✅ Wait for toast to disappear before clicking next Add Task
                WebDriverWait toastWait = new WebDriverWait(driver, Duration.ofSeconds(10));
                toastWait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("custom-toast__container")));
            
            wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[contains(text(),'Add Inquiry')]"))).click();
            
            Random rand = new Random();
            String[] firstNames = {"Palak", "Aisha", "Karan", "Mehul", "Riya"};
            String[] lastNames = {"Ramani", "Shah", "Patel", "Mehta", "Joshi"};
            String firstName = firstNames[rand.nextInt(firstNames.length)];
            String lastName = lastNames[rand.nextInt(lastNames.length)];
            String email = firstName.toLowerCase() + rand.nextInt(9999) + "@test.com";
            String phone = "9" + String.format("%09d", rand.nextInt(1000000000));


            driver.findElement(By.name("First Name")).sendKeys(firstName);
            Thread.sleep(500);
            driver.findElement(By.name("Last Name")).sendKeys(lastName);
            Thread.sleep(500);
            driver.findElement(By.name("Email ID")).sendKeys(email);
            Thread.sleep(500);
            driver.findElement(By.name("Phone No")).sendKeys(phone);
            Thread.sleep(500);

            new Select(driver.findElement(By.name("Assign To"))).selectByIndex(1);
            Thread.sleep(500);
            new Select(driver.findElement(By.name("Source Type"))).selectByVisibleText("Meta");
            Thread.sleep(500);
            new Select(driver.findElement(By.name("Inquiry Status"))).selectByVisibleText("Fresh Inquiry");
            Thread.sleep(500);
            new Select(driver.findElement(By.name("Inquiry Priority"))).selectByVisibleText("Hot");
            Thread.sleep(500);

            new Select(driver.findElement(By.xpath("//select[contains(@id,'country')]")))
                .selectByVisibleText("India");
            Thread.sleep(500);

            wait.until(d -> {
                Select s = new Select(d.findElement(By.xpath("//select[contains(@id,'state')]")));
                return s.getOptions().stream().anyMatch(o -> o.getText().equals("Gujarat"));
            });
            new Select(driver.findElement(By.xpath("//select[contains(@id,'state')]")))
                .selectByVisibleText("Gujarat");
            Thread.sleep(500);
            wait.until(d -> {
                Select s = new Select(d.findElement(By.xpath("//select[contains(@id,'city')]")));
                return s.getOptions().stream().anyMatch(o -> o.getText().equals("Ahmedabad"));
            });
            new Select(driver.findElement(By.xpath("//select[contains(@id,'city')]")))
                .selectByVisibleText("Ahmedabad");
            Thread.sleep(500);
            driver.findElement(By.name("Zip Code")).sendKeys("380009");
            Thread.sleep(500);
            driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
            Thread.sleep(500);
            // Optional wait for confirmation
            Thread.sleep(500);
            System.out.println("✅ Inquiry added successfully");

        } catch (Exception e) {
            System.err.println("❌ Failed to add inquiry: " + e.getMessage());
        }
    }
    @AfterClass
    public void afterClass() {
        System.out.println("✅ Inquiry test completed");
    }
}
