package Project;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.Test;

import java.time.Duration;

public class Import {

    private WebDriver driver;
    private WebDriverWait wait;
    private JavascriptExecutor js;

    public Import(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.js = (JavascriptExecutor) driver;
    }

    @Test
    public void testImport() {
        try {
            WebElement inquiries = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//a[contains(@href,'inquiries.index') and contains(@class,'menu-item')]")));
            js.executeScript("arguments[0].click();", inquiries);

            WebElement importBtn = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//a[contains(@href, '/import')]")));
            importBtn.click();

            WebElement radioBtn = driver.findElement(By.id("discounts"));
            if (!radioBtn.isSelected()) {
                radioBtn.click();
            }
            Thread.sleep(400);

            driver.findElement(By.xpath("//button[normalize-space()='Next']")).click();

            WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement fileInput = wait1.until(ExpectedConditions.presenceOfElementLocated(By.id("csvInput")));

            js.executeScript("arguments[0].removeAttribute('hidden')", fileInput);
            js.executeScript("arguments[0].style.display = 'block';", fileInput);
            js.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'})", fileInput);

            Thread.sleep(2000);
            String filePath = "C:\\TestImages\\Test.csv";
            fileInput.sendKeys(filePath);
            Thread.sleep(2000);

            // Dropdown mapping
            new Select(driver.findElement(By.cssSelector(
                    "body > div.wrapper > main > div > div > div > table > tbody > tr:nth-child(3) td.import-excel-body select")))
                    .selectByIndex(3);
            Thread.sleep(1000);

            new Select(driver.findElement(By.cssSelector(
                    "body > div.wrapper > main > div > div > div > table > tbody > tr:nth-child(8) td:nth-child(3) select")))
                    .selectByIndex(1);
            Thread.sleep(1000);

            new Select(driver.findElement(By.cssSelector(
                    "body > div.wrapper > main > div > div > div > table > tbody > tr:nth-child(9) td:nth-child(3) select")))
                    .selectByIndex(2);
            Thread.sleep(1000);

            new Select(driver.findElement(By.cssSelector(
                    "body > div.wrapper > main > div > div > div > table > tbody > tr:nth-child(10) td:nth-child(3) select")))
                    .selectByIndex(2);
            Thread.sleep(1000);

            new Select(driver.findElement(By.cssSelector(
                    "body > div.wrapper > main > div > div > div > table > tbody > tr:nth-child(11) td:nth-child(3) select")))
                    .selectByIndex(2);
            Thread.sleep(1000);

            new Select(driver.findElement(By.cssSelector(
                    "body > div.wrapper > main > div > div > div > table > tbody > tr:nth-child(21) td:nth-child(3) select")))
                    .selectByIndex(1);
            Thread.sleep(1000);

            new Select(driver.findElement(By.cssSelector(
                    "body > div.wrapper > main > div > div > div > table > tbody > tr:nth-child(22) td:nth-child(3) select")))
                    .selectByIndex(3);
            Thread.sleep(1000);

            new Select(driver.findElement(By.cssSelector(
                    "body > div.wrapper > main > div > div > div > table > tbody > tr:nth-child(23) td:nth-child(3) select")))
                    .selectByIndex(3);
            Thread.sleep(1000);

            driver.findElement(By.xpath("//button[normalize-space()='Next']")).click();

            WebElement startImportButton = wait1.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[normalize-space()='Start Import']")));
            startImportButton.click();
            Thread.sleep(5000);
            System.out.println("✅ Import completed successfully.");
        } catch (Exception e) {
            System.err.println("❌ Import failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
