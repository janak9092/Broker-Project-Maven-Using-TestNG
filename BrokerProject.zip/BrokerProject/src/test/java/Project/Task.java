package Project;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.*;

import java.io.File;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Task {

	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;

	public Task(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		this.js = (JavascriptExecutor) driver;
	}

	@BeforeClass
	public void openTaskPage() {
		try {
			WebElement taskMenu = wait.until(ExpectedConditions.elementToBeClickable(
					By.xpath("//a[contains(@href,'tasks.index') and contains(@class,'menu-item')]")));
			js.executeScript("arguments[0].click();", taskMenu);
		} catch (Exception e) {
			System.err.println("❌ Failed to navigate to Task page: " + e.getMessage());
		}
	}

	@Test
	public void testTask() {
		try {
			
			 new WebDriverWait(driver, Duration.ofSeconds(15)).until(
	                    ExpectedConditions.invisibilityOfElementLocated(By.className("custom-toast__container")));
			 
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Add Task')]")))
					.click();

			new Select(wait.until(ExpectedConditions.elementToBeClickable(By.id("Module"))))
					.selectByVisibleText("Inquiries");
			Thread.sleep(500);

			wait.until(driver -> {
				Select refSelect = new Select(driver.findElement(By.id("Reference ID")));
				return refSelect.getOptions().size() > 1;
			});
			Thread.sleep(500);

			Select refDropdown = new Select(driver.findElement(By.id("Reference ID")));
			List<WebElement> options = refDropdown.getOptions();

			if (options.size() > 1) {
				refDropdown.selectByIndex(1); // or random index if you prefer
			} else {
				System.err.println("❌ Not enough inquiries found to assign task.");
				return;
			}

			new Select(driver.findElement(By.id("Assign To"))).selectByIndex(1);
			Thread.sleep(500);

			wait.until(ExpectedConditions.elementToBeClickable(By.id("Title"))).sendKeys("Test Follow Up Title");
			Thread.sleep(500);

			driver.findElement(By.id("Description")).sendKeys("Auto Follow-up Description");
			Thread.sleep(500);

			WebElement startDate = driver.findElement(By.id("Start Date"));
			Thread.sleep(500);
			js.executeScript("arguments[0].scrollIntoView({ behavior: 'smooth', block: 'center' });", startDate);
			Thread.sleep(500);

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
			String currentDateTime = LocalDateTime.now().format(formatter);

			js.executeScript(
					"let start = document.getElementById('Start Date'); if(start) { start.value = arguments[0]; start.dispatchEvent(new Event('input', { bubbles: true })); start.dispatchEvent(new Event('change', { bubbles: true })); }",
					currentDateTime);

			String endDate = LocalDateTime.now().plusDays(15).format(formatter);
			js.executeScript(
					"let end = document.getElementById('End Date'); if(end) { end.value = arguments[0]; end.dispatchEvent(new Event('input', { bubbles: true })); end.dispatchEvent(new Event('change', { bubbles: true })); }",
					endDate);
			Thread.sleep(500);

			new Select(driver.findElement(By.id("Priority"))).selectByVisibleText("Medium");
			Thread.sleep(500);

			new Select(wait.until(ExpectedConditions.elementToBeClickable(By.id("Status")))).selectByIndex(1);
			Thread.sleep(500);

			WebElement remindToggle = wait
					.until(ExpectedConditions.elementToBeClickable(By.cssSelector("span.toggle-slider")));
			js.executeScript("arguments[0].click();", remindToggle);
			Thread.sleep(500);

			String remindOnDate = LocalDateTime.now().plusDays(3).format(formatter);
			js.executeScript("let remind = document.getElementById('Remind On');" + "if(remind) { "
					+ "  remind.value = arguments[0];"
					+ "  remind.dispatchEvent(new Event('input', { bubbles: true }));"
					+ "  remind.dispatchEvent(new Event('change', { bubbles: true }));" + "}", remindOnDate);
			Thread.sleep(500);

			new Select(driver.findElement(By.id("Repeat Cycle"))).selectByVisibleText("Every Week");
			Thread.sleep(500);

			String repeatEndsDate = LocalDateTime.now().plusDays(13).format(formatter);
			js.executeScript(
					"let repeatEnds = document.getElementById('Repeat Ends');" + "if(repeatEnds) { "
							+ "  repeatEnds.value = arguments[0];"
							+ "  repeatEnds.dispatchEvent(new Event('input', { bubbles: true }));"
							+ "  repeatEnds.dispatchEvent(new Event('change', { bubbles: true }));" + "}",
					repeatEndsDate);
			Thread.sleep(500);

			for (int i = 1; i <= 3; i++) {
				WebElement addBtn = wait.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//div[contains(text(),'Add Checkpoint')]")));
				js.executeScript("arguments[0].scrollIntoView(true); arguments[0].click();", addBtn);
				Thread.sleep(800);

				List<WebElement> inputs = driver.findElements(By.cssSelector("input[placeholder='Enter checkpoint']"));
				inputs.get(inputs.size() - 1).sendKeys("test " + i);
				Thread.sleep(600);
			}

			WebElement fileInput = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("fileInput")));
			js.executeScript("arguments[0].style.display = 'block'; arguments[0].style.visibility = 'visible';",
					fileInput);

			File specificImage = new File("C:\\TestImages\\Image1.jpg");

			if (specificImage.exists()) {
				fileInput.sendKeys(specificImage.getAbsolutePath());
				System.out.println("✅ Uploaded specific image: " + specificImage.getName());
				Thread.sleep(1000);
			} else {
				System.out.println("❌ Image not found: " + specificImage.getAbsolutePath());
			}

			driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
			Thread.sleep(1000);
			System.out.println("✅ Task added successfully");

		} catch (Exception e) {
			System.err.println("❌ Task creation failed: " + e.getMessage());
		}
	}

	@AfterClass
	public void finish() {
		System.out.println("✅ Task test completed.");
	}
}
