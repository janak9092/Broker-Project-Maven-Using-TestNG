package Project;

import Browser.Browser;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;
import java.util.Random;

public class SignUpFirst {

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = Browser.createDriver(); // ✅ Use Browser.java
        executeSignUp(driver);
        driver.quit(); // ✅ Always quit browser at end
    }

    public static void executeSignUp(WebDriver driver) throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://auth-staging.nineformula.com/signup");

        Random rand = new Random();
        String[] firstNames = {"Palak", "Aisha", "Karan", "Mehul", "Riya"};
        String[] lastNames = {"Ramani", "Shah", "Patel", "Mehta", "Joshi"};
        String firstName = firstNames[rand.nextInt(firstNames.length)];
        String lastName = lastNames[rand.nextInt(lastNames.length)];
        String email = firstName.toLowerCase() + rand.nextInt(9999) + "@test.com";
        String phone = "9" + String.format("%09d", rand.nextInt(1000000000));

     // Fill Sign Up Form
		driver.findElement(By.xpath("//input[@placeholder='First name']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@placeholder='Last name']")).sendKeys(lastName);
        driver.findElement(By.xpath("//input[@placeholder='Email ID']")).sendKeys(email);
        driver.findElement(By.xpath("//input[@placeholder='XXXXXXXXXX']")).sendKeys(phone);
        driver.findElement(By.xpath("//input[@placeholder='Enter password']")).sendKeys("Test@1234");
        driver.findElement(By.xpath("//input[@placeholder='Re-create password']")).sendKeys("Test@1234");
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();",
                driver.findElement(By.xpath("//input[@type='checkbox']")));

        ((JavascriptExecutor) driver).executeScript("arguments[0].click();",
                driver.findElement(By.xpath("//button[contains(text(),'Continue')]")));

        // Email OTP
        wait.until(ExpectedConditions.urlContains("/email/verify"));
        fillOtpFast(driver, "111111");
        clickFast(driver, "//button[contains(text(),'Verify') or contains(text(),'Continue')]");

        // Phone OTP
        wait.until(ExpectedConditions.urlContains("/phone/verify"));
        fillOtpFast(driver, "111111");
        clickFast(driver, "//button[contains(text(),'Verify') or contains(text(),'Continue')]");
        Thread.sleep(2000);
      
    }

    public static void fillOtpFast(WebDriver driver, String otp) {
        List<WebElement> otpBoxes = new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("input.otp-input")));
        for (int i = 0; i < otp.length() && i < otpBoxes.size(); i++) {
            otpBoxes.get(i).clear();
            otpBoxes.get(i).sendKeys(Character.toString(otp.charAt(i)));
        }
    }

    public static void clickFast(WebDriver driver, String xpath) {
        WebElement button = new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", button);
        
        try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
}
